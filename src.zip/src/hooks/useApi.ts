// Custom React Hooks for API Data Fetching
// These hooks encapsulate loading states, error handling, and data management

import { useState, useEffect } from 'react';
import { apiService, ApiClientError } from '../services/apiService';
import type {
  PredictionRequest,
  PredictionResponse,
  TrainingMetrics,
  ModelArchitecture,
  HistoricalData,
} from '../types/api';

/**
 * Generic type for async operation state
 * This pattern is commonly used for tracking API calls
 */
interface AsyncState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

/**
 * Hook for making flight delay predictions
 * 
 * Returns an object with:
 * - predict: function to call with flight details
 * - result: the prediction response
 * - loading: boolean indicating if request is in progress
 * - error: error message if request failed
 * - reset: function to clear the result
 * 
 * Example usage in a component:
 * const { predict, result, loading, error } = usePrediction();
 * 
 * const handleSubmit = async () => {
 *   await predict({ dayOfWeek: 2, month: 6, ... });
 * };
 */
export function usePrediction() {
  const [state, setState] = useState<AsyncState<PredictionResponse>>({
    data: null,
    loading: false,
    error: null,
  });

  const predict = async (request: PredictionRequest) => {
    // Set loading state
    setState({ data: null, loading: true, error: null });

    try {
      // Call the API service
      const result = await apiService.prediction.predict(request);
      
      // Update state with successful result
      setState({ data: result, loading: false, error: null });
      
      return result;
    } catch (error) {
      // Extract error message
      const errorMessage = error instanceof ApiClientError 
        ? error.message 
        : 'An unexpected error occurred';
      
      // Update state with error
      setState({ data: null, loading: false, error: errorMessage });
      
      // Re-throw so caller can handle if needed
      throw error;
    }
  };

  const reset = () => {
    setState({ data: null, loading: false, error: null });
  };

  return {
    predict,
    result: state.data,
    loading: state.loading,
    error: state.error,
    reset,
  };
}

/**
 * Hook for fetching training metrics
 * This uses useEffect to automatically fetch data when component mounts
 * 
 * Example usage:
 * const { metrics, loading, error, refetch } = useTrainingMetrics();
 */
export function useTrainingMetrics() {
  const [state, setState] = useState<AsyncState<TrainingMetrics>>({
    data: null,
    loading: true,
    error: null,
  });

  const fetchMetrics = async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const result = await apiService.metrics.getMetrics();
      setState({ data: result, loading: false, error: null });
    } catch (error) {
      const errorMessage = error instanceof ApiClientError 
        ? error.message 
        : 'Failed to load training metrics';
      
      setState({ data: null, loading: false, error: errorMessage });
    }
  };

  // useEffect runs after component mounts
  // Empty dependency array [] means it only runs once
  useEffect(() => {
    fetchMetrics();
  }, []);

  return {
    metrics: state.data,
    loading: state.loading,
    error: state.error,
    refetch: fetchMetrics, // Allow manual refresh
  };
}

/**
 * Hook for fetching model architecture
 */
export function useModelArchitecture() {
  const [state, setState] = useState<AsyncState<ModelArchitecture>>({
    data: null,
    loading: true,
    error: null,
  });

  const fetchArchitecture = async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const result = await apiService.model.getArchitecture();
      setState({ data: result, loading: false, error: null });
    } catch (error) {
      const errorMessage = error instanceof ApiClientError 
        ? error.message 
        : 'Failed to load model architecture';
      
      setState({ data: null, loading: false, error: errorMessage });
    }
  };

  useEffect(() => {
    fetchArchitecture();
  }, []);

  return {
    architecture: state.data,
    loading: state.loading,
    error: state.error,
    refetch: fetchArchitecture,
  };
}

/**
 * Hook for fetching paginated training data
 * This demonstrates how to handle parameters that change over time
 * 
 * The dependency array [page, pageSize, searchTerm] means useEffect
 * will re-run whenever any of these values change
 */
export function useTrainingData(
  page: number = 1,
  pageSize: number = 15,
  searchTerm?: string
) {
  const [state, setState] = useState<AsyncState<{
    data: HistoricalData[];
    total: number;
  }>>({
    data: null,
    loading: true,
    error: null,
  });

  const fetchData = async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const result = await apiService.data.getTrainingData(
        page,
        pageSize,
        searchTerm
      );
      setState({ data: result, loading: false, error: null });
    } catch (error) {
      const errorMessage = error instanceof ApiClientError 
        ? error.message 
        : 'Failed to load training data';
      
      setState({ data: null, loading: false, error: errorMessage });
    }
  };

  // Re-fetch whenever page, pageSize, or searchTerm changes
  useEffect(() => {
    fetchData();
  }, [page, pageSize, searchTerm]);

  return {
    data: state.data?.data || [],
    total: state.data?.total || 0,
    loading: state.loading,
    error: state.error,
    refetch: fetchData,
  };
}

/**
 * Hook for fetching dataset statistics
 */
export function useDatasetStats() {
  const [state, setState] = useState<AsyncState<{
    totalRecords: number;
    delayedCount: number;
    onTimeCount: number;
  }>>({
    data: null,
    loading: true,
    error: null,
  });

  const fetchStats = async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const result = await apiService.data.getStats();
      setState({ data: result, loading: false, error: null });
    } catch (error) {
      const errorMessage = error instanceof ApiClientError 
        ? error.message 
        : 'Failed to load dataset statistics';
      
      setState({ data: null, loading: false, error: errorMessage });
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  return {
    stats: state.data,
    loading: state.loading,
    error: state.error,
    refetch: fetchStats,
  };
}

/**
 * Hook for fetching available airports and carriers
 * This demonstrates fetching multiple endpoints in parallel
 */
export function useReferenceData() {
  const [state, setState] = useState<AsyncState<{
    airports: string[];
    carriers: string[];
  }>>({
    data: null,
    loading: true,
    error: null,
  });

  const fetchReferenceData = async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      // Promise.all runs both requests in parallel
      // This is more efficient than sequential requests
      const [airports, carriers] = await Promise.all([
        apiService.prediction.getAirports(),
        apiService.prediction.getCarriers(),
      ]);

      setState({
        data: { airports, carriers },
        loading: false,
        error: null,
      });
    } catch (error) {
      const errorMessage = error instanceof ApiClientError 
        ? error.message 
        : 'Failed to load reference data';
      
      setState({ data: null, loading: false, error: errorMessage });
    }
  };

  useEffect(() => {
    fetchReferenceData();
  }, []);

  return {
    airports: state.data?.airports || [],
    carriers: state.data?.carriers || [],
    loading: state.loading,
    error: state.error,
    refetch: fetchReferenceData,
  };
}
